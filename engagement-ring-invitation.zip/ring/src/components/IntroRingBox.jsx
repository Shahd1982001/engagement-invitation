import { useEffect, useRef, useState } from 'react'
import * as THREE from 'three'
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js'
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js'
import gsap from 'gsap'

function glowTexture() {
  const s = 128, cv = document.createElement('canvas'); cv.width = cv.height = s
  const x = cv.getContext('2d'), g = x.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2)
  g.addColorStop(0, 'rgba(255,246,222,1)'); g.addColorStop(0.35, 'rgba(255,226,170,.45)'); g.addColorStop(1, 'rgba(255,226,170,0)')
  x.fillStyle = g; x.fillRect(0, 0, s, s)
  return new THREE.CanvasTexture(cv)
}

// علبة خاتم مخملية 3D: تنفتح تلقائيًا، ثم الضغط على الخاتم يقرّبنا منه ويدخل على الدعوة
export default function IntroRingBox({ onDone, veilRef, reduce }) {
  const mount = useRef(null), btn = useRef(null), go = useRef(() => {})
  const [phase, setPhase] = useState('closed') // closed | ready | going | fallback

  useEffect(() => {
    const el = mount.current, b = btn.current
    let renderer
    try { renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' }) }
    catch { setPhase('fallback'); go.current = () => gsap.to(veilRef.current, { opacity: 1, duration: 1.2, onComplete: onDone }); return }

    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75))
    renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.1
    el.appendChild(renderer.domElement)
    const scene = new THREE.Scene()
    const pm = new THREE.PMREMGenerator(renderer), envRT = pm.fromScene(new RoomEnvironment(), 0.04)
    scene.environment = envRT.texture
    const cam = new THREE.PerspectiveCamera(36, 1, 0.1, 100)

    const velvet = new THREE.MeshPhysicalMaterial({ color: '#5a0f24', roughness: 0.85, sheen: 1, sheenRoughness: 0.5, sheenColor: new THREE.Color('#c25a78'), envMapIntensity: 0.5 })
    const cushionMat = new THREE.MeshPhysicalMaterial({ color: '#7a1a33', roughness: 0.9, sheen: 1, sheenColor: new THREE.Color('#d98ea4') })
    const gold = new THREE.MeshStandardMaterial({ color: '#e0c079', metalness: 1, roughness: 0.22 })
    const gemMat = new THREE.MeshPhysicalMaterial({ color: '#ffffff', roughness: 0, metalness: 0.1, clearcoat: 1, envMapIntensity: 3, flatShading: true, emissive: new THREE.Color('#ffffff'), emissiveIntensity: 0.1 })

    const geos = [new RoundedBoxGeometry(2.2, 1, 1.8, 4, 0.08), new RoundedBoxGeometry(2, 0.2, 1.6, 3, 0.05), new THREE.BoxGeometry(2.24, 0.04, 1.84),
      new RoundedBoxGeometry(2.2, 0.55, 1.8, 4, 0.08), new THREE.TorusGeometry(0.3, 0.055, 24, 64), new THREE.OctahedronGeometry(0.1)]
    const box = new THREE.Group(); scene.add(box)
    const base = new THREE.Mesh(geos[0], velvet); base.position.y = 0.5
    const cushion = new THREE.Mesh(geos[1], cushionMat); cushion.position.y = 0.98
    const rimTrim = new THREE.Mesh(geos[2], gold); rimTrim.position.y = 1.0
    const lid = new THREE.Group(); lid.position.set(0, 1.02, -0.9)
    const lidMesh = new THREE.Mesh(geos[3], velvet); lidMesh.position.set(0, 0.275, 0.9)
    const lidTrim = new THREE.Mesh(geos[2], gold); lidTrim.position.set(0, 0.02, 0.9)
    lid.add(lidMesh, lidTrim)
    const ring = new THREE.Group(); ring.position.set(0, 1.45, 0)
    const band = new THREE.Mesh(geos[4], gold), gem = new THREE.Mesh(geos[5], gemMat)
    gem.position.y = 0.37; gem.scale.set(1, 1.25, 1); ring.add(band, gem)
    const glowTex = glowTexture()
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, transparent: true, opacity: 0, depthTest: false, blending: THREE.AdditiveBlending }))
    glow.position.set(0, 1.55, 0.2); glow.renderOrder = 2
    box.add(base, cushion, rimTrim, lid, ring, glow)

    scene.add(new THREE.AmbientLight('#ffd9e2', 0.35))
    const key = new THREE.DirectionalLight('#fff0d8', 2.2); key.position.set(2, 6, 4); scene.add(key)
    const rimL = new THREE.DirectionalLight('#ff9fb8', 1.1); rimL.position.set(-4, 2, -3); scene.add(rimL)
    const pl = new THREE.PointLight('#ffe9c0', 0, 6); pl.position.set(0, 2.2, 0.8); scene.add(pl)

    const st = { open: 0, glow: 0, dolly: 0, scale: 1, spark: 0 }
    const camBase = new THREE.Vector3(), camEnd = new THREE.Vector3(0, 1.6, 1.9)
    const lookA = new THREE.Vector3(0, 1.1, 0), lookB = new THREE.Vector3(0, 1.5, 0), look = new THREE.Vector3()
    let w = 1, h = 1
    const resize = () => {
      w = el.clientWidth; h = el.clientHeight; renderer.setSize(w, h); cam.aspect = w / h
      const d = Math.max(7, 3.6 / (2 * Math.tan((cam.fov * Math.PI) / 360) * cam.aspect))
      camBase.set(0, d * 0.42, d * 0.9); cam.updateProjectionMatrix()
    }
    resize(); window.addEventListener('resize', resize)

    const clock = new THREE.Clock(), tmp = new THREE.Vector3()
    let raf
    const frame = () => {
      raf = requestAnimationFrame(frame)
      const t = clock.getElapsedTime()
      lid.rotation.x = -st.open * 1.95
      box.rotation.y = Math.sin(t * 0.4) * 0.08 * (1 - st.dolly)
      ring.rotation.y = Math.sin(t * 0.9) * 0.5; ring.scale.setScalar(st.scale)
      ring.position.y = 1.45 + Math.sin(t * 1.6) * 0.02 * st.glow
      gemMat.emissiveIntensity = 0.1 + (0.5 + 0.5 * Math.sin(t * 3)) * 0.5 * st.glow + st.spark
      pl.intensity = st.glow * 5 + st.spark * 20
      glow.material.opacity = Math.min(1, st.glow * 0.7 + st.spark); glow.scale.setScalar(1.3 + st.glow * 0.4 + st.spark * 5)
      cam.position.lerpVectors(camBase, camEnd, st.dolly)
      cam.lookAt(look.lerpVectors(lookA, lookB, st.dolly))
      renderer.render(scene, cam)
      ring.getWorldPosition(tmp); tmp.y += 0.12
      const dist = cam.position.distanceTo(tmp)
      const px = (0.9 * st.scale / (2 * Math.tan((cam.fov * Math.PI) / 360) * dist)) * h
      tmp.project(cam)
      b.style.transform = `translate(${(tmp.x * 0.5 + 0.5) * w}px,${(-tmp.y * 0.5 + 0.5) * h}px) translate(-50%,-50%)`
      b.style.width = b.style.height = `${Math.max(72, px)}px`
    }
    frame()

    const open = gsap.timeline({ delay: reduce ? 0.2 : 0.9 })
    open.to(st, { open: 1, duration: reduce ? 0.8 : 2.8, ease: 'power2.inOut' })
      .to(st, { glow: 1, duration: 1.4, ease: 'sine.out' }, '>-0.8')
      .add(() => setPhase('ready'))

    let zoom
    go.current = () => {
      const d = reduce ? 0.9 : 2.4
      zoom = gsap.timeline({ onComplete: onDone })
      zoom.to(st, { dolly: 1, scale: 1.3, duration: d, ease: 'power2.in' }, 0)
        .to(st, { spark: 1, duration: d * 0.8, ease: 'power1.in' }, 0)
        .to(veilRef.current, { opacity: 1, duration: d * 0.45, ease: 'power1.in' }, d * 0.6)
    }

    return () => {
      open.kill(); zoom && zoom.kill(); cancelAnimationFrame(raf); window.removeEventListener('resize', resize)
      ;[...geos, velvet, cushionMat, gold, gemMat, glow.material, glowTex, envRT, pm].forEach((o) => o.dispose && o.dispose())
      renderer.dispose(); renderer.domElement.remove()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const click = () => { if (phase !== 'ready' && phase !== 'fallback') return; setPhase('going'); go.current() }

  return (
    <section className="intro" aria-label="افتتاحية الدعوة">
      <div className="intro-canvas" ref={mount} aria-hidden="true" />
      <button ref={btn} className={`ring-hit ${phase}`} onClick={click} disabled={phase === 'closed' || phase === 'going'} aria-label="اضغطي على الخاتم لفتح الدعوة" />
      <p className={`intro-hint ${phase === 'ready' || phase === 'fallback' ? 'show' : ''}`} aria-live="polite">اضغطي على الخاتم</p>
    </section>
  )
}
