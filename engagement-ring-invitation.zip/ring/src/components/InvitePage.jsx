import { useLayoutEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { invite } from '../config/invite.js'
import { dateParts } from '../utils/dateParts.js'
import Monogram from './Monogram.jsx'
import RSVPDialog from './RSVPDialog.jsx'

const hide = (e) => { e.currentTarget.style.visibility = 'hidden' }

// صفحة واحدة: القوس الملكي + الخطيبان بينهما مسافة + نصوص موزعة بحرية
export default function InvitePage({ reduce }) {
  const root = useRef(null)
  const [rsvp, setRsvp] = useState(false)
  const d = dateParts(invite.dateTime, invite.timeZone)

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const q = gsap.utils.selector(root.current)
      if (reduce) { gsap.from(q('.arch,.person,.fx,.actions'), { autoAlpha: 0, duration: 0.6 }); return }
      gsap.timeline({ defaults: { ease: 'power2.out' } })
        .from(q('.arch'), { scale: 1.12, duration: 3.2, ease: 'power1.out' }, 0)
        .from(q('.person.bride'), { xPercent: -30, autoAlpha: 0, duration: 2, ease: 'power2.inOut' }, 0.4)
        .from(q('.person.groom'), { xPercent: 30, autoAlpha: 0, duration: 2, ease: 'power2.inOut' }, 0.4)
        .from(q('.ringfx'), { scale: 0.2, autoAlpha: 0, duration: 1.6 }, 1.6)
        .from(q('.fx'), { y: 18, autoAlpha: 0, duration: 1.1, stagger: 0.28 }, 1.2)
        .from(q('.actions'), { y: 20, autoAlpha: 0, duration: 1 }, 3)
    }, root)
    return () => ctx.revert()
  }, [reduce])

  return (
    <main className="page" ref={root}>
      <div className="arch" role="img" aria-label="قوس ملكي مزيّن بالورود" />
      <div className="shade" aria-hidden="true" />

      <header className="top">
        <div className="fx"><Monogram a={invite.brideLatin} b={invite.groomLatin} /></div>
        <h1 className="names fx"><span>{invite.bride}</span><i aria-hidden="true">&amp;</i><span>{invite.groom}</span></h1>
        <p className="line fx">{invite.line}</p>
      </header>

      <section className="info" aria-label="تفاصيل الحفل">
        <div className="fx date"><small>{d.weekday}</small><strong>{d.day}</strong><span>{d.month} {d.year}</span></div>
        <div className="fx time"><small>الساعة</small><strong>{d.time}</strong><span>{d.ampm}</span></div>
        <div className="fx place"><small>المكان</small><strong>{invite.placeName}</strong><span>{invite.city}</span></div>
      </section>

      <img className="person bride" src="/assets/bride.png" alt="العروس" onError={hide} />
      <img className="person groom" src="/assets/groom.png" alt="العريس" onError={hide} />
      <div className="ringfx" aria-hidden="true"><svg viewBox="0 0 40 40"><circle cx="20" cy="24" r="9" fill="none" stroke="#f0dba4" strokeWidth="2.4" /><path d="M20 15 l-3.5-4.5 h7z" fill="#fff" /></svg></div>

      <nav className="actions" aria-label="إجراءات">
        <a className="btn-gold" href={invite.mapsUrl} target="_blank" rel="noopener noreferrer">عرض الموقع</a>
        <button className="btn-line" onClick={() => setRsvp(true)}>تأكيد الحضور</button>
      </nav>
      {rsvp && <RSVPDialog onClose={() => setRsvp(false)} />}
    </main>
  )
}
